<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="hr">
<context>
    <name>QQuickPlatformDialog</name>
    <message>
        <source>Dialog is an abstract base class</source>
        <translation>Dijalog je apstraktna osnovna klasa</translation>
    </message>
    <message>
        <source>Cannot create an instance of StandardButton</source>
        <translation>Nije moguće izraditi standardni gumb</translation>
    </message>
</context>
<context>
    <name>QtQuickControls2ImagineStylePlugin</name>
    <message>
        <source>Imagine is an attached property</source>
        <translation>Imagine je priloženo svojstvo</translation>
    </message>
</context>
<context>
    <name>QtQuickControls2MaterialStylePlugin</name>
    <message>
        <source>Material is an attached property</source>
        <translation>Material je priloženo svojstvo</translation>
    </message>
</context>
<context>
    <name>QtQuickControls2UniversalStylePlugin</name>
    <message>
        <source>Universal is an attached property</source>
        <translation>Universal je priloženo svojstvo</translation>
    </message>
</context>
</TS>
